import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'token_details_page.dart';
import 'transaction_history_page.dart';
import 'TokenSendReceivePage.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget{
 @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.deepPurple,
        secondaryHeaderColor: Colors.pink,
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Poppins',
        textTheme: TextTheme(
          headline6: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          bodyText2: TextStyle(fontSize: 16),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            primary: Colors.pink,
            textStyle: TextStyle(fontSize: 18),
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
      ),
      home: CryptoWalletApp(),
    );
  }
}
class CryptoWalletApp extends StatefulWidget {
  @override
  _CryptoWalletAppState createState() => _CryptoWalletAppState();
}

class _CryptoWalletAppState extends State<CryptoWalletApp> {
  List<Token> tokens = [];

  @override
  void initState() {
    super.initState();
    fetchTokens();
  }

  Future<void> fetchTokens() async {
    final response = await http.get(Uri.parse('https://api.coingecko.com/api/v3/coins/ethereum'));
    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);
      final List<dynamic> tokenData = jsonData['market_data']['current_price'].keys.toList();
      setState(() {
        tokens = tokenData.map((token) => Token(name: token)).toList();
      });
    } else {
      throw Exception('Failed to fetch tokens');
    }
  }

@override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Crypto Wallet',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                      color: Colors.deepPurple,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.history,
                     color: Colors.deepPurple),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => TransactionHistoryPage(),
                        ),
                      );
                    },
                  ),
                ],
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TokenSendReceivePage(action: 'Receive'),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.deepPurple,
                  textStyle: TextStyle(fontSize: 18),
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: Text('Receive Tokens',style: TextStyle(color: Colors.white),),
              ),
              SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TokenSendReceivePage(action: 'Send'),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                  primary: Colors.pink,
                  
                  textStyle: TextStyle(fontSize: 18),
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              child: Text('Send Tokens'),
            ),
              SizedBox(height: 50),
              Container(
                
                height: 30,
                width: 50,
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 230, 181, 237),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
            BoxShadow(
              color: Color.fromARGB(255, 232, 193, 206) ,
              blurRadius: 2.0,
              offset: Offset(2.0,2.0)
            )
          ]
             
                  ),
                
                  child: Center(
                    child: Title(color: Colors.deepPurple, 
                    child: Text(
                      'List of Tokens',
                      style: TextStyle(color: Colors.white, fontSize: 18, fontFamily: 'Poppins', fontWeight: FontWeight.bold)),
                                  ),
                  )
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: tokens.length,
                  itemBuilder: (context, index) {
                    final token = tokens[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: ListTile(title: Text(
    token.name,
    style: TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    ),
    ),
    onTap: () {
    Navigator.push(
    context,
    MaterialPageRoute(
    builder: (context) => TokenDetailsPage(tokenName: token.name),
    ),
    );
    },
    ),
    ),
    );
    },
    ),
    ),
    ],
    ),
    ),
    ),
    );
}}
class Token {
  final String name;

  Token({required this.name});
}
