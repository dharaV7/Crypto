import 'package:flutter/material.dart';

class TokenSendReceivePage extends StatelessWidget {
  final String action;

  TokenSendReceivePage({required this.action});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('$action Tokens',
        style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
      ),
      body: Center(
        child: Text('$action Tokens Page'),
      ),
    );
  }
}
