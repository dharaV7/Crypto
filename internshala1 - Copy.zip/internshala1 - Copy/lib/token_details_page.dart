import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class TokenDetailsPage extends StatelessWidget {
  final String tokenName;

  TokenDetailsPage({required this.tokenName});

  Future<Map<String, dynamic>> fetchTokenDetails() async {
    final response =
        await http.get(Uri.parse('https://api.coingecko.com/api/v3/coins/ethereum'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to fetch token details');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Token Details',
        style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.deepPurple,
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchTokenDetails(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final tokenData = snapshot.data!['market_data']['current_price'][tokenName];
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Token: $tokenName',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text('Price: $tokenData USD'),
                  SizedBox(height: 10),
                  // Add more token details here as needed
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
